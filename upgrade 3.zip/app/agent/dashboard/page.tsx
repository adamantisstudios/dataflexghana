"use client"
import { useState, useEffect, useRef, Suspense, useCallback, useMemo } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import {
  LogOut,
  Plus,
  MessageCircle,
  Banknote,
  ExternalLink,
  Smartphone,
  Settings,
  Search,
  TrendingUp,
  Package,
  Filter,
  Briefcase,
  MapPin,
  DollarSign,
  Building2,
  Mail,
  Wallet,
  X,
  ShoppingBag,
  PiggyBank,
  Shield,
  ArrowRight,
  Users,
  CreditCard,
} from "lucide-react"
import { BackToTop } from "@/components/back-to-top"
import AgentReminderPopup from "@/components/agent-reminder-popup"
import DashboardLoginNotification from "@/components/agent/DashboardLoginNotification"
import AgentDashboardNotification from "@/components/agent/AgentDashboardNotification"
import { useUnreadMessages } from "@/hooks/use-unread-messages"
import { supabase } from "@/lib/supabase"
import type { Job } from "@/lib/supabase"
import { RichTextRenderer } from "@/components/ui/rich-text-renderer"
import { ImageWithFallback } from "@/components/ui/image-with-fallback"
import { ImageModal } from "@/components/ui/image-modal"
import { calculateCompleteEarnings } from "@/lib/earnings-calculator"
import { AgentMenuCards } from "@/components/agent/AgentMenuCards"
import { getAgentCommissionSummary } from "@/lib/commission-earnings"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { FloatingAudioPlayer } from "@/components/floating-audio-player"
import { ProductSlider } from "@/components/agent/ProductSlider"
import AgentPropertiesShowcase from "@/components/agent/dashboard/AgentPropertiesShowcase"
import DashboardFloatingChat from "@/components/agent/dashboard/DashboardFloatingChat"
import { ComplianceTab } from "@/components/agent/compliance/ComplianceTab"
import { ProfessionalWritingTab } from "@/components/agent/professional-writing/ProfessionalWritingTab"
import TeachingPlatformPage from "@/app/agent/teaching/page"
import { useAgentDashboardCache } from "@/hooks/use-agent-dashboard-cache"
import { loadAgentDashboardData, loadTabData } from "@/lib/agent-dashboard-loader"
import { DashboardSkeleton } from "@/components/agent/dashboard-skeleton"
import ReferralDashboard from "@/components/agent/referral-program/ReferralDashboard"

const safeCommissionDisplay = (value: number | null | undefined): number => {
  if (value === null || value === undefined || isNaN(value)) {
    return 0
  }
  return Number(value)
}

export default function AgentDashboard() {
  const router = useRouter()
  const { getFromCache, setInCache } = useAgentDashboardCache()
  // The 'agent' variable is used before it's declared.
  // Declare 'agent' state before using it in useUnreadMessages.
  const [agent, setAgent] = useState(null) // Moved up to resolve lint error
  const { unreadCount, getUnreadCount, markAsRead } = useUnreadMessages(agent?.id || "", "agent")

  const [loading, setLoading] = useState(true)
  const [earningsData, setEarningsData] = useState({
    totalEarnings: 0,
    totalPaidEarnings: 0,
    pendingPayout: 0,
    availableBalance: 0,
    walletBalance: 0,
    referralCommissions: 0,
    dataOrderCommissions: 0,
    wholesaleCommissions: 0,
  })

  const [tabData, setTabData] = useState({
    referrals: [],
    dataOrders: [],
    wholesaleOrders: [],
    withdrawals: [],
    paidWithdrawals: [],
    services: [],
    dataBundles: [],
    jobs: [],
  })

  const [activeTab, setActiveTab] = useState("services")
  const [loadedTabs, setLoadedTabs] = useState<Record<string, boolean>>({})
  const [tabLoadingStates, setTabLoadingStates] = useState<Record<string, boolean>>({})

  const [showReferralDialog, setShowReferralDialog] = useState(false)
  const [referralWhatsApp, setReferralWhatsApp] = useState("")
  const [referralWhatsAppError, setReferralWhatsAppError] = useState("")
  const [showDomesticReferralDialog, setShowDomesticReferralDialog] = useState(false)
  const [domesticReferralWhatsApp, setDomesticReferralWhatsApp] = useState("")
  const [domesticReferralWhatsAppError, setDomesticReferralWhatsAppError] = useState("")
  const [showNotification, setShowNotification] = useState(true)
  const [showWalletStrategy, setShowWalletStrategy] = useState(true)
  const [showImageModal, setShowImageModal] = useState(false)
  const [modalImages, setModalImages] = useState<string[]>([])
  const [modalImageIndex, setModalImageIndex] = useState(0)
  const [modalImageAlt, setModalImageAlt] = useState("")
  const [showStatistics, setShowStatistics] = useState(false)
  const [statisticsLoading, setStatisticsLoading] = useState(false)
  const [showDashboardAudioPlayer, setShowDashboardAudioPlayer] = useState(false)
  const [showDashboardAudio, setShowDashboardAudio] = useState(true)
  const [agentId, setAgentId] = useState<string | null>(null) // Keep agentId for specific functionalities

  const [notificationVisible, setNotificationVisible] = useState(false)

  const [currentServicesPage, setCurrentServicesPage] = useState(1)
  const [currentReferralsPage, setCurrentReferralsPage] = useState(1)
  const [currentWithdrawalsPage, setCurrentWithdrawalsPage] = useState(1)
  const [currentPaidWithdrawalsPage, setCurrentPaidWithdrawalsPage] = useState(1)
  const [currentJobsPage, setCurrentJobsPage] = useState(1)
  const [itemsPerPage] = useState(10)

  const [servicesSearchTerm, setServicesSearchTerm] = useState("")
  const [servicesFilter, setServicesFilter] = useState("All Services")
  const [referralsFilter, setReferralsFilter] = useState("All Referrals")
  const [dataBundlesFilter, setDataBundlesFilter] = useState("All Networks")
  const [jobSearchTerm, setJobSearchTerm] = useState("")
  const [jobsFilterAgent, setJobsFilterAgent] = useState("All Jobs")

  // Refs for scrolling
  const menuSectionRef = useRef<HTMLDivElement>(null)
  const smartWalletRef = useRef<HTMLDivElement>(null)
  const walletTopupRef = useRef<HTMLDivElement>(null)
  const performanceRef = useRef<HTMLDivElement>(null)
  const statisticsRef = useRef<HTMLDivElement>(null)

  const filteredServices = useMemo(() => {
    if (!loadedTabs.services) return []
    let filtered = tabData.services.filter(
      (service) =>
        service.title?.toLowerCase().includes(servicesSearchTerm.toLowerCase()) ||
        service.description?.toLowerCase().includes(servicesSearchTerm.toLowerCase()),
    )
    if (servicesFilter !== "All Services") {
      filtered = filtered.filter((service) => {
        const commission = service.commission_amount
        switch (servicesFilter) {
          case "GH₵0-1000":
            return commission >= 0 && commission <= 1000
          case "GH₵1001-5000":
            return commission >= 1001 && commission <= 5000
          case "GH₵5001+":
            return commission >= 5001
          default:
            return true
        }
      })
    }
    return filtered
  }, [servicesSearchTerm, tabData.services, servicesFilter, loadedTabs.services])

  const filteredReferrals = useMemo(() => {
    if (!loadedTabs.referrals) return []
    let filtered = tabData.referrals
    if (referralsFilter !== "All Referrals") {
      filtered = tabData.referrals.filter((referral) => {
        switch (referralsFilter) {
          case "Pending":
            return referral.status === "pending"
          case "Confirmed":
            return referral.status === "confirmed"
          case "In Progress":
            return referral.status === "in_progress"
          case "Completed":
            return referral.status === "completed"
          case "Rejected":
            return referral.status === "rejected"
          default:
            return true
        }
      })
    }
    return filtered
  }, [tabData.referrals, referralsFilter, loadedTabs.referrals])

  const filteredJobs = useMemo(() => {
    if (!loadedTabs.jobs) return []
    let filtered = tabData.jobs.filter(
      (job) =>
        job.is_active &&
        (job.title?.toLowerCase().includes(jobSearchTerm.toLowerCase()) ||
          job.company?.toLowerCase().includes(jobSearchTerm.toLowerCase()) ||
          job.location?.toLowerCase().includes(jobSearchTerm.toLowerCase()) ||
          job.industry?.toLowerCase().includes(jobSearchTerm.toLowerCase())),
    )
    if (jobsFilterAgent !== "All Jobs") {
      filtered = filtered.filter((job) => {
        switch (jobsFilterAgent) {
          case "Featured":
            return job.is_featured === true
          case "Technology":
          case "Finance":
          case "Healthcare":
          case "Education":
          case "Marketing":
          case "Sales":
          case "Customer Service":
            return job.industry === jobsFilterAgent
          default:
            return true
        }
      })
    }
    return filtered
  }, [jobSearchTerm, tabData.jobs, jobsFilterAgent, loadedTabs.jobs])

  const checkWalletStrategyDisplay = () => {
    const lastShown = localStorage.getItem("walletStrategyLastShown")
    const today = new Date().toDateString()
    if (!lastShown || lastShown !== today) {
      setShowWalletStrategy(true)
    }
  }

  useEffect(() => {
    const wasClosed = localStorage.getItem("dashboardAudioPlayerClosed")
    if (!wasClosed) {
      setShowDashboardAudioPlayer(true)
    }
    checkWalletStrategyDisplay() // Check wallet strategy on mount
  }, [])

  useEffect(() => {
    // Delay showing notification by 7 seconds
    const notificationTimer = setTimeout(() => {
      setNotificationVisible(true)
    }, 7000)

    // Hide notification after another 7 seconds (total 14 seconds)
    const hideTimer = setTimeout(() => {
      setNotificationVisible(false)
    }, 14000)

    return () => {
      clearTimeout(notificationTimer)
      clearTimeout(hideTimer)
    }
  }, [])

  const handleCloseWalletStrategy = () => {
    const today = new Date().toDateString()
    localStorage.setItem("walletStrategyLastShown", today)
    setShowWalletStrategy(false)
  }

  const handleCloseAudioPlayer = () => {
    setShowDashboardAudioPlayer(false)
    localStorage.setItem("dashboardAudioPlayerClosed", "true")
  }

  const getCurrentAgent = () => {
    const agentData = localStorage.getItem("agent")
    if (!agentData) {
      return null
    }
    return JSON.parse(agentData)
  }

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const agentData = localStorage.getItem("agent")
        if (!agentData) {
          router.push("/agent/login")
          return
        }

        const parsedAgent = JSON.parse(agentData)
        setAgent(parsedAgent)
        setAgentId(parsedAgent.id) // Set agentId here

        const cachedData = getFromCache(`dashboard-${parsedAgent.id}`)
        if (cachedData) {
          setEarningsData(cachedData.earnings)
          setTabData((prev) => ({
            ...prev,
            referrals: cachedData.referrals,
            dataOrders: cachedData.dataOrders,
            wholesaleOrders: cachedData.wholesaleOrders,
            withdrawals: cachedData.withdrawals,
            paidWithdrawals: cachedData.paidWithdrawals,
          }))
          setLoadedTabs({
            referrals: true,
            dataOrders: true,
            wholesaleOrders: true,
            withdrawals: true,
            paidWithdrawals: true,
          })
          setLoading(false)
          return
        }

        const dashboardData = await loadAgentDashboardData(parsedAgent.id)

        const earnings = {
          totalEarnings: dashboardData.commissionSummary.totalEarned || 0,
          availableBalance: dashboardData.commissionSummary.availableForWithdrawal || 0,
          pendingPayout: dashboardData.commissionSummary.pendingWithdrawal || 0,
          totalPaidEarnings: dashboardData.commissionSummary.totalWithdrawn || 0,
          walletBalance: Number(dashboardData.agentData?.wallet_balance) || 0,
          referralCommissions: 0,
          dataOrderCommissions: 0,
          wholesaleCommissions: 0,
        }

        setEarningsData(earnings)
        setTabData((prev) => ({
          ...prev,
          referrals: dashboardData.referralsData,
          dataOrders: dashboardData.dataOrdersData,
          wholesaleOrders: dashboardData.wholesaleOrdersData,
          withdrawals: dashboardData.withdrawalsData,
          paidWithdrawals: dashboardData.paidWithdrawalsData,
        }))

        setInCache(`dashboard-${parsedAgent.id}`, {
          earnings,
          referrals: dashboardData.referralsData,
          dataOrders: dashboardData.dataOrdersData,
          wholesaleOrders: dashboardData.wholesaleOrdersData,
          withdrawals: dashboardData.withdrawalsData,
          paidWithdrawals: dashboardData.paidWithdrawalsData,
        })

        setLoadedTabs({
          referrals: true,
          dataOrders: true,
          wholesaleOrders: true,
          withdrawals: true,
          paidWithdrawals: true,
        })
      } catch (error) {
        console.error("Error loading dashboard data:", error)
        // Show a user-friendly error message
        alert("Failed to load dashboard data. Please refresh the page or try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadInitialData()
  }, [])

  const loadStatistics = async () => {
    if (!agent?.id || showStatistics) return
    setStatisticsLoading(true)
    try {
      setShowStatistics(true)
      // If you have specific logic to load statistics data, add it here
      // For now, just showing the section
    } catch (error) {
      console.error("Error loading statistics:", error)
    } finally {
      setStatisticsLoading(false)
    }
  }

  const calculateEarnings = async (agentId: string, agentData: any) => {
    try {
      const earnings = await calculateCompleteEarnings(agentId)
      setEarningsData({
        totalEarnings: earnings.totalEarnings,
        totalPaidEarnings: earnings.totalPaidOut,
        pendingPayout: earnings.pendingPayout,
        availableBalance: earnings.availableBalance,
        walletBalance: 0, // This will be fetched separately or updated
        referralCommissions: 0,
        dataOrderCommissions: 0,
        wholesaleCommissions: 0,
      })
    } catch (error) {
      console.error("Error calculating earnings:", error)
      setEarningsData({
        totalEarnings: 0,
        totalPaidEarnings: 0,
        pendingPayout: 0,
        availableBalance: 0,
        walletBalance: 0,
        referralCommissions: 0,
        dataOrderCommissions: 0,
        wholesaleCommissions: 0,
      })
    }
  }

  const handleTabChange = useCallback(
    async (tab: string) => {
      setActiveTab(tab)
      if (loadedTabs[tab] || !agent?.id) return

      setTabLoadingStates((prev) => ({ ...prev, [tab]: true }))
      try {
        const data = await loadTabData(tab, agent.id)
        if (data) {
          // Use the correct key for services data based on the loadTabData function's return
          if (tab === "services") {
            setTabData((prev) => ({ ...prev, services: data.services }))
          } else if (tab === "data-bundles") {
            setTabData((prev) => ({
              ...prev,
              dataBundles: data.dataBundles,
              dataOrders: data.dataOrders,
            }))
          } else if (tab === "jobs") {
            setTabData((prev) => ({ ...prev, jobs: data }))
          }
          // For other tabs, data might already be set in loadTabData or handled differently
          // Ensure consistency with loadTabData return values
          if (tab === "referrals") setTabData((prev) => ({ ...prev, referrals: data }))
          if (tab === "withdrawals") setTabData((prev) => ({ ...prev, withdrawals: data }))
          if (tab === "paid-commissions") setTabData((prev) => ({ ...prev, paidWithdrawals: data }))
          if (tab === "wholesale") setTabData((prev) => ({ ...prev, wholesaleOrders: data }))
        }
        setLoadedTabs((prev) => ({ ...prev, [tab]: true }))
      } catch (error) {
        console.error(`Error loading ${tab} data:`, error)
      } finally {
        setTabLoadingStates((prev) => ({ ...prev, [tab]: false }))
      }
    },
    [agent?.id, loadedTabs],
  )

  // useEffect(() => {
  //   const wasClosed = localStorage.getItem("dashboardAudioPlayerClosed")
  //   if (!wasClosed) {
  //     setShowDashboardAudioPlayer(true)
  //   }
  //   checkWalletStrategyDisplay() // Check wallet strategy on mount
  // }, [])

  // useEffect(() => {
  //   // Delay showing notification by 7 seconds
  //   const notificationTimer = setTimeout(() => {
  //     setNotificationVisible(true)
  //   }, 7000)

  //   // Hide notification after another 7 seconds (total 14 seconds)
  //   const hideTimer = setTimeout(() => {
  //     setNotificationVisible(false)
  //   }, 14000)

  //   return () => {
  //     clearTimeout(notificationTimer)
  //     clearTimeout(hideTimer)
  //   }
  // }, [])

  // useEffect(() => {
  //   if (!loadedTabs.services) return
  //   // Filtering logic moved to useMemo
  // }, [servicesSearchTerm, services, servicesFilter, loadedTabs.services])

  // useEffect(() => {
  //   if (!loadedTabs.referrals) return
  //   // Filtering logic moved to useMemo
  // }, [referrals, referralsFilter, loadedTabs.referrals])

  const ensureJobTitle = (job: Job): Job => {
    if (!job.title && job.industry) {
      return { ...job, title: job.industry }
    }
    return job
  }

  // useEffect(() => {
  //   if (!loadedTabs.jobs) return
  //   // Filtering logic moved to useMemo
  // }, [jobSearchTerm, jobs, jobsFilterAgent, loadedTabs.jobs])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const getPaginatedData = (data: any[], currentPage: number) => {
    const startIndex = (currentPage - 1) * itemsPerPage
    const endIndex = startIndex + itemsPerPage
    return data.slice(startIndex, endIndex)
  }

  const getTotalPages = (dataLength: number) => {
    return Math.ceil(dataLength / itemsPerPage)
  }

  const handlePageChange = (newPage: number, setCurrentPage: (page: number) => void) => {
    setCurrentPage(newPage)
    scrollToTop()
  }

  const PaginationControls = ({
    currentPage,
    totalPages,
    onPageChange,
  }: {
    currentPage: number
    totalPages: number
    onPageChange: (page: number) => void
  }) => {
    if (totalPages <= 1) return null
    const getVisiblePages = () => {
      const isMobile = typeof window !== "undefined" && window.innerWidth < 768
      const maxVisible = isMobile ? 3 : 5
      if (totalPages <= maxVisible) {
        return Array.from({ length: totalPages }, (_, i) => i + 1)
      }
      const start = Math.max(1, currentPage - Math.floor(maxVisible / 2))
      const end = Math.min(totalPages, start + maxVisible - 1)
      const adjustedStart = Math.max(1, end - maxVisible + 1)
      return Array.from({ length: end - adjustedStart + 1 }, (_, i) => adjustedStart + i)
    }
    const visiblePages = getVisiblePages()
    return (
      <div className="flex justify-center mt-4 sm:mt-6">
        <Pagination>
          <PaginationContent className="gap-1 sm:gap-2">
            <PaginationItem>
              <PaginationPrevious
                onClick={() => currentPage > 1 && onPageChange(currentPage - 1)}
                className={`${
                  currentPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"
                } h-8 px-2 sm:h-10 sm:px-4 text-xs sm:text-sm`}
              />
            </PaginationItem>
            {visiblePages[0] > 1 && (
              <>
                <PaginationItem>
                  <PaginationLink
                    onClick={() => onPageChange(1)}
                    className="cursor-pointer h-8 w-8 sm:h-10 sm:w-10 text-xs sm:text-sm"
                  >
                    1
                  </PaginationLink>
                </PaginationItem>
                {visiblePages[0] > 2 && (
                  <PaginationItem>
                    <span className="flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center text-xs sm:text-text-sm">
                      ...
                    </span>
                  </PaginationItem>
                )}
              </>
            )}
            {visiblePages.map((pageNum) => (
              <PaginationItem key={pageNum}>
                <PaginationLink
                  onClick={() => onPageChange(pageNum)}
                  isActive={currentPage === pageNum}
                  className="cursor-pointer h-8 w-8 sm:h-10 sm:w-10 text-xs sm:text-sm"
                >
                  {pageNum}
                </PaginationLink>
              </PaginationItem>
            ))}
            {visiblePages[visiblePages.length - 1] < totalPages && (
              <>
                {visiblePages[visiblePages.length - 1] < totalPages - 1 && (
                  <PaginationItem>
                    <span className="flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center text-xs sm:text-sm">
                      ...
                    </span>
                  </PaginationItem>
                )}
                <PaginationItem>
                  <PaginationLink
                    onClick={() => onPageChange(totalPages)}
                    className="cursor-pointer h-8 w-8 sm:h-10 sm:w-10 text-xs sm:text-sm"
                  >
                    {totalPages}
                  </PaginationLink>
                </PaginationItem>
              </>
            )}
            <PaginationItem>
              <PaginationNext
                onClick={() => currentPage < totalPages && onPageChange(currentPage + 1)}
                className={`${
                  currentPage >= totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"
                } h-8 px-2 sm:h-10 sm:px-4 text-xs sm:text-sm`}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>
    )
  }

  const handleLogout = () => {
    localStorage.removeItem("agent")
    router.push("/")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "confirmed":
      case "in_progress":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "processing":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "completed":
        return "bg-emerald-100 text-emerald-800 border-emerald-200"
      case "rejected":
      case "canceled":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString() + " - " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const getFilteredDataBundles = (provider: string) => {
    if (dataBundlesFilter === "All Networks") {
      return tabData.dataBundles.filter((bundle) => bundle.provider === provider)
    }
    return tabData.dataBundles.filter((bundle) => bundle.provider === provider && bundle.provider === dataBundlesFilter)
  }

  const openImageModal = (images: string[], index: number, alt: string) => {
    setModalImages(images.filter((img) => img && img.trim() !== ""))
    setModalImageIndex(index)
    setModalImageAlt(alt)
    setShowImageModal(true)
  }

  const loadEarningsData = async () => {
    if (!agentId) return
    try {
      setLoading(true)
      const commissionSummary = await getAgentCommissionSummary(agentId)
      setEarningsData({
        totalEarnings: commissionSummary.totalEarned || 0,
        availableBalance: commissionSummary.availableForWithdrawal || 0,
        pendingPayout: commissionSummary.pendingWithdrawal || 0,
        totalPaidEarnings: commissionSummary.totalWithdrawn || 0,
        walletBalance: 0, // This will be fetched separately or updated
        referralCommissions: 0,
        dataOrderCommissions: 0,
        wholesaleCommissions: 0,
      })
      const { data: agentData } = await supabase.from("agents").select("wallet_balance").eq("id", agentId).single()
      if (agentData) {
        setEarningsData((prev) => ({
          ...prev,
          walletBalance: Number(agentData.wallet_balance) || 0,
        }))
      }
    } catch (error) {
      console.error("Error loading earnings data:", error)
    } finally {
      setLoading(false)
    }
  }

  // useEffect(() => {
  //   const loadData = async () => {
  //     if (!agentId) return
  //     // This effect is now handled by the main useEffect that loads initial data
  //   }
  //   loadData()
  // }, [agentId])

  const validateWhatsAppNumber = (number: string) => {
    const cleanNumber = number.replace(/\D/g, "")
    if (cleanNumber.length === 10 && cleanNumber.startsWith("0")) {
      return `233${cleanNumber.substring(1)}`
    } else if (cleanNumber.length === 12 && cleanNumber.startsWith("233")) {
      return cleanNumber
    } else if (cleanNumber.length === 9) {
      return `233${cleanNumber}`
    }
    return null
  }

  const handleReferralSubmit = () => {
    if (!referralWhatsApp.trim()) {
      setReferralWhatsAppError("Please enter a WhatsApp number")
      return
    }
    const validatedNumber = validateWhatsAppNumber(referralWhatsApp)
    if (!validatedNumber) {
      setReferralWhatsAppError("Please enter a valid Ghana WhatsApp number (e.g., 0241234567 or 233241234567)")
      return
    }
    const message = `🚀 *Join DataFlex Ghana as an Agent Today!* 🚀
Hello! I'm ${agent?.full_name}, and I want to invite you to join an amazing opportunity to earn extra income as a DataFlex Ghana Agent! 💰
✨ *What You'll Get:*
✅ Earn commissions on every sale
✅ Flexible working hours
✅ No upfront investment required
✅ Access to multiple income streams
✅ Professional training and support
*Register here:* ${typeof window !== "undefined" ? window.location.origin : "https://dataflexghana.com"}/agent/register
⚠️ *IMPORTANT:* After completing your registration, please contact the admin on WhatsApp at +233242799990 and mention that *${agent?.full_name}* recommended you to register. This ensures you get proper onboarding support!
Don't miss this opportunity to start earning today! 💰
Best regards,
${agent?.full_name}
DataFlex Ghana Agent`
    const whatsappUrl = `https://wa.me/${validatedNumber}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
    setShowReferralDialog(false)
    setReferralWhatsApp("")
    setReferralWhatsAppError("")
  }

  const handleWhatsAppChange = (value: string) => {
    setReferralWhatsApp(value)
    setReferralWhatsAppError("")
  }

  const handleDomesticReferralSubmit = () => {
    if (!domesticReferralWhatsApp.trim()) {
      setDomesticReferralWhatsAppError("Please enter a WhatsApp number")
      return
    }
    const validatedNumber = validateWhatsAppNumber(domesticReferralWhatsApp)
    if (!validatedNumber) {
      setDomesticReferralWhatsAppError("Please enter a valid Ghana WhatsApp number (e.g., 0241234567 or 233241234567)")
      return
    }
    const message = `🏠 *Find Your Dream Domestic Job Today!* 🏠
Hello! I'm ${agent?.full_name}, and I want to help you find amazing domestic work opportunities in Ghana and abroad! 🌍
✨ *Why Choose DataFlex Ghana for Domestic Work?*
✅ NO Registration Fees - Join for FREE! 💰
✅ NO Processing Fees - Keep what you earn! 💵
✅ NO Salary Deductions - 100% of your pay is yours! 🎯
✅ Your Labor Rights are Protected 🛡️
✅ Good Monthly Salary Guaranteed 💸
✅ Clients Agree to Treat You Well 🤝
✅ Time to Rest and Take Breaks ⏰
*Register Now:* ${typeof window !== "undefined" ? window.location.origin : "https://dataflexghana.com"}/domestic-workers
Don't miss this opportunity to secure a better future! Join thousands of domestic workers who have found great jobs through our platform.
Best regards,
${agent?.full_name}
DataFlex Ghana Agent 🇬🇭`
    const whatsappUrl = `https://wa.me/${validatedNumber}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
    setShowDomesticReferralDialog(false)
    setDomesticReferralWhatsApp("")
    setDomesticReferralWhatsAppError("")
  }

  const handleDomesticWhatsAppChange = (value: string) => {
    setDomesticReferralWhatsApp(value)
    setDomesticReferralWhatsAppError("")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50 flex items-center justify-center">
        <DashboardSkeleton />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-white">
      <DashboardLoginNotification />
      <AgentDashboardNotification />
      {showDashboardAudioPlayer && (
        <FloatingAudioPlayer
          audioSrc="/agent_dashboard_intro.mp3"
          title="Dashboard Guide"
          description="Learn to maximize your earnings"
          onClose={handleCloseAudioPlayer}
        />
      )}
      <div className="bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 shadow-lg border-b-2 border-emerald-700">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-lg shadow flex items-center justify-center p-1.5">
                <img src="/images/logo.png" alt="DataFlex Logo" className="w-full h-full object-contain" />
              </div>
              <div>
                <h1 className="text-lg lg:text-xl font-bold text-white drop-shadow-sm">Data Flex Agent</h1>
                <p className="text-emerald-100 text-xs font-medium">Welcome back, {agent?.full_name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                asChild
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 h-9 px-2"
              >
                <Link href="/agent/settings">
                  <Settings className="h-3.5 w-3.5 mr-1" />
                  <span className="hidden sm:inline text-xs">Settings</span>
                </Link>
              </Button>
              <Button
                variant="secondary"
                onClick={handleLogout}
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 h-9 px-2"
              >
                <LogOut className="h-3.5 w-3.5 mr-1" />
                <span className="hidden sm:inline text-xs">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-8">
        {showNotification && (
          <div className="relative mb-6 p-4 bg-gradient-to-r from-emerald-500 to-green-500 text-white rounded-lg shadow-lg border-l-4 border-l-emerald-700">
            <button
              onClick={() => setShowNotification(false)}
              className="absolute top-4 right-4 text-white hover:text-emerald-100"
            >
              <X />
            </button>
            <div className="space-y-3">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                Promote Services
              </h3>
              <div className="text-white space-y-2 text-sm leading-relaxed">
                <ul className="list-disc list-inside">
                  <li>Promote services and refer projects for bigger commissions and cashout bonuses.</li>
                  <li>Promote to friends, family, and people who need these services.</li>
                </ul>
              </div>
            </div>
          </div>
        )}
        <AgentMenuCards activeTab={activeTab} onTabChange={handleTabChange} />
        <div className="mb-8">
          <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50 hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-blue-800">Educational Products & Services</h3>
                    <p className="text-blue-600">Results Checker Cards, School Forms & Subscriptions</p>
                  </div>
                </div>
                <Button
                  asChild
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 w-full md:w-auto"
                >
                  <Link href="/voucher">
                    <ShoppingBag className="h-4 w-4 mr-2" />
                    Shop Educational Products
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main 2-Column Layout for Desktop */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* LEFT COLUMN - Video, About, Statistics (1/3 width) */}
          <div className="lg:col-span-1 space-y-6">
            {/* Video Player */}
            <div className="rounded-lg overflow-hidden shadow-lg bg-gray-100">
              <div className="relative w-full bg-black" style={{ aspectRatio: "16/9" }}>
                <div className="absolute top-4 right-4 bg-black/20 text-white px-3 py-1 rounded text-sm font-medium backdrop-blur-sm z-10">
                  Agent ID: {agent?.id?.slice(-6) || "XXXXXX"}
                </div>
                <video
                  width="1920"
                  height="1080"
                  controls
                  preload="metadata"
                  className="w-full h-full object-cover"
                  poster="/adamantis_introvideo_poster.jpg"
                  style={{ aspectRatio: "16/9" }}
                >
                  <source src="/adamantis_introvideo.mp4" type="video/mp4" />
                  <source src="/adamantis_introvideo.webm" type="video/webm" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>

            {/* About Adamantis Section */}
            <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-lg shadow-lg border border-emerald-200 p-6">
              <h3 className="text-xl font-bold text-emerald-800 mb-3">About Adamantis Studios</h3>
              <p className="text-emerald-700 text-sm leading-relaxed mb-2">
                Adamantis Studios is a holistic marketing and IT firm offering comprehensive services to help businesses
                grow and thrive in today's competitive market.
              </p>
              <Button
                asChild
                size="sm"
                className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white w-full"
              >
                <Link href="https://www.adamantisstudios.com" target="_blank" rel="noopener noreferrer">
                  Learn More
                  <ArrowRight className="ml-2 h-3 w-3" />
                </Link>
              </Button>
            </div>

            {/* Dashboard Statistics */}
            <div>
              {!showStatistics ? (
                <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                  <CardContent className="pt-6 text-center py-6">
                    <div className="space-y-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto">
                        <TrendingUp className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-emerald-800 mb-2">Statistics</h3>
                        <p className="text-emerald-600 text-sm mb-3">View your performance and earnings</p>
                      </div>
                      <Button
                        onClick={loadStatistics}
                        disabled={statisticsLoading}
                        size="sm"
                        className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 w-full"
                      >
                        {statisticsLoading ? (
                          <>
                            <div className="animate-spin rounded-full h-3 w-3 border-2 border-white border-t-transparent mr-2"></div>
                            Loading...
                          </>
                        ) : (
                          <>
                            <TrendingUp className="h-4 w-4 mr-2" />
                            Load Stats
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Statistics</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowStatistics(false)}
                        className="h-6 w-6 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="bg-gradient-to-br from-emerald-500 to-green-600 text-white rounded-lg p-4">
                        <p className="text-xs text-emerald-100 font-medium">Total Commissions</p>
                        <p className="text-2xl font-bold">
                          GH₵ {safeCommissionDisplay(earningsData.availableBalance || 0).toFixed(2)}
                        </p>
                      </div>
                      <div className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white rounded-lg p-4">
                        <p className="text-xs text-purple-100 font-medium">Wallet Balance</p>
                        <p className="text-2xl font-bold">
                          GH₵ {safeCommissionDisplay(earningsData.walletBalance || 0).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN - Wallet, Referral, Properties & Products (2/3 width) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Smart Wallet Strategy */}
            {showWalletStrategy && (
              <div className="p-5 bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-lg shadow-lg border-l-4 border-l-blue-700 relative">
                <button
                  onClick={handleCloseWalletStrategy}
                  className="absolute top-3 right-3 text-white hover:text-blue-100 transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
                <div className="space-y-2 pr-7">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Wallet className="h-4 w-4" />
                    Smart Wallet Strategy
                  </h3>
                  <ul className="list-disc list-inside space-y-0.5 text-blue-100 text-xs">
                    <li>
                      <strong>One-time charge:</strong> When you load wallet
                    </li>
                    <li>
                      <strong>No fees:</strong> When you buy from wallet
                    </li>
                    <li>
                      <strong>Save more:</strong> Than manual payments
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {/* Wallet Top-Up */}
            <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg shadow-lg p-5 border border-purple-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <CreditCard className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Top Up Wallet</h3>
                  <p className="text-purple-100 text-xs">Add funds for faster purchases</p>
                </div>
              </div>
              <Button asChild size="sm" className="w-full bg-white text-purple-600 hover:bg-purple-50 font-medium">
                <Link href="/agent/wallet?tab=topup">
                  <Plus className="h-4 w-4 mr-2" />
                  Top Up Wallet
                </Link>
              </Button>
            </div>

            {/* Invite Friends */}
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg shadow-lg p-5 border border-green-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Invite Friends</h3>
                  <p className="text-green-100 text-xs">Earn ₵15 when they join</p>
                </div>
              </div>
              <Button
                onClick={() => setShowReferralDialog(true)}
                size="sm"
                className="w-full bg-white text-green-600 hover:bg-green-50 font-medium"
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Send Referral Message
              </Button>
            </div>

            {/* Properties Showcase */}
            <div>
              <AgentPropertiesShowcase />
            </div>

            {/* Products Slider */}
            <div>
              <ProductSlider />
            </div>
          </div>
        </div>

        {/* Remove the old duplicated sections below - they're now in the grid above */}
        <div className="max-w-7xl mx-auto mb-8">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
            <TabsContent value="voucher-cards" className="space-y-4"></TabsContent>

            <TabsContent value="referral-program" className="space-y-4">
              {agent?.id && (
                <ReferralDashboard agentId={agent.id} agentName={agent.agent_name || agent.full_name || "Agent"} />
              )}
            </TabsContent>

            <TabsContent value="wholesale" className="space-y-4">
              <AgentPropertiesShowcase />
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold text-emerald-800">Wholesale Shopping</h2>
                <Button
                  asChild
                  className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 w-full sm:w-auto"
                >
                  <Link href="/agent/wholesale">
                    <ShoppingBag className="h-4 w-4 mr-2" />
                    Start Shopping
                  </Link>
                </Button>
              </div>
              <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                <CardContent className="pt-6 text-center py-12">
                  <ShoppingBag className="h-16 w-16 mx-auto mb-4 text-emerald-300" />
                  <h3 className="text-xl font-semibold text-emerald-800 mb-2">Wholesale Products</h3>
                  <p className="text-emerald-600 mb-6">
                    Browse and purchase wholesale products with competitive pricing and earn commissions on every
                    purchase.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-6">
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <Package className="h-8 w-8 mx-auto mb-1 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Quality Products</h4>
                      <p className="text-sm text-emerald-600">Curated wholesale products across multiple categories</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <DollarSign className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Competitive Pricing</h4>
                      <p className="text-sm text-emerald-600">Get the best wholesale prices with bulk discounts</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Earn Commissions</h4>
                      <p className="text-sm text-emerald-600">Earn money on every wholesale purchase you make</p>
                    </div>
                  </div>
                  <Button
                    asChild
                    className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                  >
                    <Link href="/agent/wholesale">
                      <ShoppingBag className="h-4 w-4 mr-2" />
                      Browse Wholesale Products
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="services" className="space-y-4">
              {tabLoadingStates.services ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                  <span className="ml-3 text-emerald-700">Loading services...</span>
                </div>
              ) : (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <h2 className="text-2xl font-bold text-emerald-800">Available Services</h2>
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                      <div className="flex gap-2">
                        <Select value={servicesFilter} onValueChange={setServicesFilter}>
                          <SelectTrigger className="w-full sm:w-48 border-emerald-200 focus:border-emerald-500 bg-white/80 backdrop-blur-sm">
                            <Filter className="h-4 w-4 mr-2" />
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="All Services">All Services</SelectItem>
                            <SelectItem value="GH₵0-1000">GH₵0-1000</SelectItem>
                            <SelectItem value="GH₵1001-5000">GH₵1001-5000</SelectItem>
                            <SelectItem value="GH₵5001+">GH₵5001+</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-400 h-4 w-4" />
                        <Input
                          placeholder="Search services..."
                          value={servicesSearchTerm}
                          onChange={(e) => setServicesSearchTerm(e.target.value)}
                          className="pl-10 w-full sm:w-64 border-emerald-200 focus:border-emerald-500 bg-white/80 backdrop-blur-sm"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {getPaginatedData(filteredServices, currentServicesPage).map((service) => (
                      <Card
                        key={service.id}
                        className="hover:shadow-xl transition-all duration-300 border-emerald-200 bg-white/90 backdrop-blur-sm hover:scale-105"
                      >
                        <CardHeader>
                          {service.image_url && (
                            <div className="w-full h-48 bg-gradient-to-br from-emerald-100 to-green-100 rounded-lg mb-2 overflow-hidden cursor-pointer">
                              <ImageWithFallback
                                src={service.image_url || "/placeholder.svg"}
                                alt={service.title}
                                className="w-full h-full object-cover hover:scale-105 transition-transform"
                                onClick={() => openImageModal([service.image_url], 0, service.title)}
                                fallbackSrc="/placeholder.svg?height=192&width=400"
                              />
                            </div>
                          )}
                          <CardTitle className="text-lg text-emerald-800">{service.title}</CardTitle>
                          <CardDescription className="text-emerald-600">
                            <RichTextRenderer content={service.description} />
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-emerald-600">Commission:</span>
                              <span className="text-xl font-bold text-green-600">
                                GH₵ {safeCommissionDisplay(service.commission_amount).toFixed(2)}
                              </span>
                            </div>
                            {service.product_cost && (
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-emerald-600">Product Cost:</span>
                                <span className="text-sm font-semibold text-emerald-800">
                                  GH₵ {safeCommissionDisplay(service.product_cost).toFixed(2)}
                                </span>
                              </div>
                            )}
                            <div className="flex gap-2 pt-2">
                              <Button
                                asChild
                                className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 flex-1"
                              >
                                <Link href={`/agent/refer/${service.id}`}>
                                  <Plus className="h-4 w-4 mr-2" />
                                  Refer
                                </Link>
                              </Button>
                              {service.material?.material_link && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  asChild
                                  className="border-emerald-300 text-emerald-600 bg-transparent"
                                >
                                  <Link href={service.material.material_link} target="_blank">
                                    <ExternalLink className="h-4 w-4" />
                                  </Link>
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  <PaginationControls
                    currentPage={currentServicesPage}
                    totalPages={getTotalPages(filteredServices.length)}
                    onPageChange={(page) => handlePageChange(page, setCurrentServicesPage)}
                  />
                </>
              )}
            </TabsContent>
            <TabsContent value="data-bundles" className="space-y-4">
              {tabLoadingStates["data-bundles"] ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                  <span className="ml-3 text-emerald-700">Loading data bundles...</span>
                </div>
              ) : (
                <>
                  <div className="text-center space-y-4">
                    <h2 className="text-2xl font-bold text-emerald-800">Data Bundles</h2>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                      <Button
                        asChild
                        size="sm"
                        className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                      >
                        <Link href="/agent/data-order">
                          <Plus className="h-4 w-4 sm:mr-2" />
                          <span className="hidden sm:inline">Order Data</span>
                          <span className="sm:hidden">Order Data</span>
                        </Link>
                      </Button>
                      <Button
                        asChild
                        size="sm"
                        className="w-full sm:w-auto bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                      >
                        <Link href="/agent/data-orders">
                          <Smartphone className="h-4 w-4 sm:mr-2" />
                          <span className="hidden sm:inline">View All Orders</span>
                          <span className="sm:hidden">View All Orders</span>
                        </Link>
                      </Button>
                    </div>
                  </div>
                  <Tabs defaultValue="MTN" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm shadow-lg border border-emerald-200 p-1 rounded-xl">
                      {["MTN", "AirtelTigo", "Telecel"].map((provider) => {
                        const logoMap = {
                          MTN: "/images/mtn-logo.jpg",
                          AirtelTigo: "/images/airteltigo-logo.jpg",
                          Telecel: "/images/telecel-logo.jpg",
                        }
                        const bundleCount = getFilteredDataBundles(provider).length
                        return (
                          <TabsTrigger
                            key={provider}
                            value={provider}
                            className="text-xs lg:text-sm font-medium data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-500 data-[state=active]:to-green-500 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-200 rounded-lg p-2 lg:p-3 flex items-center justify-center gap-2"
                          >
                            <img
                              src={logoMap[provider] || "/placeholder.svg"}
                              alt={`${provider} logo`}
                              className="w-5 h-5 rounded object-cover"
                            />
                            <div className="flex flex-col items-center">
                              <span className="hidden sm:inline">{provider}</span>
                              <span className="text-xs opacity-75">({bundleCount})</span>
                            </div>
                          </TabsTrigger>
                        )
                      })}
                    </TabsList>
                    {["MTN", "AirtelTigo", "Telecel"].map((provider) => {
                      const providerBundles = getFilteredDataBundles(provider).sort((a, b) => a.size_gb - b.size_gb)
                      return (
                        <TabsContent key={provider} value={provider} className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h3 className="text-xl font-semibold text-emerald-700 flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg overflow-hidden shadow-md border-2 border-emerald-200">
                                <img
                                  src={
                                    provider === "MTN"
                                      ? "/images/mtn.jpg"
                                      : provider === "AirtelTigo"
                                        ? "/images/airteltigo.jpg"
                                        : "/images/telecel.jpg"
                                  }
                                  alt={`${provider} logo`}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <span>{provider} Data Bundles</span>
                            </h3>
                            <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                              {providerBundles.length} bundles
                            </Badge>
                          </div>
                          {providerBundles.length === 0 ? (
                            <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                              <CardContent className="pt-6 text-center">
                                <div className="text-gray-500 mb-4">
                                  <Smartphone className="h-12 w-12 mx-auto mb-2 opacity-50" />
                                  <p>No data bundles available for {provider}</p>
                                  <p className="text-sm">Check back later for new bundles</p>
                                </div>
                              </CardContent>
                            </Card>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                              {providerBundles.map((bundle) => (
                                <Card
                                  key={bundle.id}
                                  className="border-emerald-200 bg-white/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:scale-105"
                                >
                                  <CardHeader>
                                    {bundle.image_url && (
                                      <div className="w-full h-32 bg-gradient-to-br from-emerald-100 to-green-100 rounded-lg mb-2 overflow-hidden cursor-pointer">
                                        <ImageWithFallback
                                          src={bundle.image_url || "/placeholder.svg"}
                                          alt={bundle.name}
                                          className="w-full h-full object-cover hover:scale-105 transition-transform"
                                          onClick={() => openImageModal([bundle.image_url], 0, bundle.name)}
                                          fallbackSrc="/placeholder.svg"
                                        />
                                      </div>
                                    )}
                                    <CardTitle className="text-lg text-emerald-800">{bundle.name}</CardTitle>
                                    <CardDescription className="text-emerald-600 flex items-center gap-2">
                                      <img
                                        src={
                                          bundle.provider === "MTN"
                                            ? "/images/mtn.jpg"
                                            : bundle.provider === "AirtelTigo"
                                              ? "/images/airteltigo.jpg"
                                              : "/images/telecel.jpg"
                                        }
                                        alt={`${bundle.provider} logo`}
                                        className="w-5 h-5 rounded object-cover"
                                      />
                                      {bundle.size_gb}GB - {bundle.provider}
                                    </CardDescription>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="space-y-2 mb-4">
                                      <div className="flex items-center justify-between">
                                        <span className="text-sm text-emerald-600">Price:</span>
                                        <span className="text-lg font-bold text-emerald-800">
                                          GH₵ {safeCommissionDisplay(bundle.price).toFixed(2)}
                                        </span>
                                      </div>
                                      <div className="flex items-center justify-between">
                                        <span className="text-sm text-emerald-600">Commission:</span>
                                        <span className="text-lg font-bold text-green-600">
                                          GH₵ {safeCommissionDisplay(bundle.price * bundle.commission_rate).toFixed(2)}
                                        </span>
                                      </div>
                                      <div className="flex items-center justify-between">
                                        <span className="text-sm text-emerald-600">Validity:</span>
                                        <span className="text-sm font-semibold text-emerald-800">
                                          {bundle.validity_months} Months
                                        </span>
                                      </div>
                                    </div>
                                    <Button
                                      asChild
                                      className="w-full bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                                    >
                                      <Link href={`/agent/data-order?bundle=${bundle.id}`}>
                                        <Plus className="h-4 w-4 mr-1" />
                                        Order Now
                                      </Link>
                                    </Button>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>
                          )}
                        </TabsContent>
                      )
                    })}
                  </Tabs>
                </>
              )}
            </TabsContent>
            <TabsContent value="referrals" className="space-y-4">
              {tabLoadingStates.referrals ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                  <span className="ml-3 text-emerald-700">Loading referrals...</span>
                </div>
              ) : (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <h2 className="text-2xl font-bold text-emerald-800">My Referrals</h2>
                    <div className="flex items-center gap-4">
                      <Select value={referralsFilter} onValueChange={setReferralsFilter}>
                        <SelectTrigger className="w-48 border-emerald-200 focus:border-emerald-500 bg-white/80 backdrop-blur-sm">
                          <Filter className="h-4 w-4 mr-2" />
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="All Referrals">All Referrals</SelectItem>
                          <SelectItem value="Pending">Pending</SelectItem>
                          <SelectItem value="Confirmed">Confirmed</SelectItem>
                          <SelectItem value="In Progress">In Progress</SelectItem>
                          <SelectItem value="Completed">Completed</SelectItem>
                          <SelectItem value="Rejected">Rejected</SelectItem>
                        </SelectContent>
                      </Select>
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                        {filteredReferrals.length} referrals
                      </Badge>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {getPaginatedData(filteredReferrals, currentReferralsPage).map((referral) => (
                      <Card
                        key={referral.id}
                        className="border-emerald-200 bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                      >
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-emerald-800 text-lg">{referral.services?.title}</h3>
                              <Badge className={getStatusColor(referral.status)}>
                                {referral.status.replace("_", " ")}
                              </Badge>
                            </div>
                            <div className="space-y-2">
                              <p className="text-emerald-600">
                                <span className="font-medium">Client:</span> {referral.client_name} •{" "}
                                {referral.client_phone}
                              </p>
                              <p className="text-emerald-600">{referral.description}</p>
                              <div className="flex items-center gap-2 mt-2">
                                {referral.allow_direct_contact === false ? (
                                  <Badge className="bg-amber-100 text-amber-800 border-amber-200 text-xs">
                                    🚫 No Direct Client Contact
                                  </Badge>
                                ) : (
                                  <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                                    ✅ Direct Client Contact OK
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center justify-between pt-2 border-t border-emerald-100">
                              <div>
                                <p className="text-lg font-bold text-green-600">
                                  GH₵ {safeCommissionDisplay(referral.services?.commission_amount).toFixed(2)}
                                </p>
                                <p className="text-xs text-emerald-500">Commission</p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-emerald-600">
                                  {referral.status === "completed" && referral.commission_paid
                                    ? "✅ Paid"
                                    : referral.status === "completed"
                                      ? "💰 Ready to withdraw"
                                      : "⏳ In progress"}
                                </p>
                                <p className="text-xs text-emerald-500">{formatTimestamp(referral.created_at)}</p>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-3 border-t border-emerald-100">
                              <Button
                                variant="outline"
                                size="sm"
                                asChild
                                className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 relative bg-transparent"
                              >
                                <Link href={`/agent/chat/${referral.id}`} onClick={() => markAsRead(referral.id)}>
                                  <div className="relative flex items-center">
                                    <MessageCircle className="h-4 w-4 mr-2" />
                                    Chat with Admin
                                    {getUnreadCount(referral.id) > 0 && (
                                      <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center animate-pulse font-bold">
                                        {getUnreadCount(referral.id) > 9 ? "9+" : getUnreadCount(referral.id)}
                                      </span>
                                    )}
                                  </div>
                                </Link>
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {getPaginatedData(filteredReferrals, currentReferralsPage).length === 0 && (
                      <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                        <CardContent className="text-center py-8">
                          <div className="text-gray-500 mb-4">
                            <MessageCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                            <p>
                              {referralsFilter === "All Referrals"
                                ? "No referrals yet. Start referring services to earn commissions!"
                                : `No ${referralsFilter.toLowerCase()} referrals found.`}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                  <PaginationControls
                    currentPage={currentReferralsPage}
                    totalPages={getTotalPages(filteredReferrals.length)}
                    onPageChange={(page) => handlePageChange(page, setCurrentReferralsPage)}
                  />
                </>
              )}
            </TabsContent>
            <TabsContent value="withdrawals" className="space-y-4">
              {tabLoadingStates.withdrawals ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                  <span className="ml-3 text-emerald-700">Loading withdrawals...</span>
                </div>
              ) : (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <h2 className="text-2xl font-bold text-emerald-800">Withdrawal History</h2>
                    <div className="flex items-center gap-4">
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                        {tabData.withdrawals.length} withdrawals
                      </Badge>
                      <Button
                        asChild
                        className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                      >
                        <Link href="/agent/withdraw">
                          <Plus className="h-4 w-4 mr-2" />
                          Request Withdrawal
                        </Link>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {getPaginatedData(tabData.withdrawals, currentWithdrawalsPage).map((withdrawal) => (
                      <Card
                        key={withdrawal.id}
                        className="border-emerald-200 bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                      >
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-emerald-800 text-lg">
                                GH₵ {safeCommissionDisplay(withdrawal.amount).toFixed(2)}
                              </h3>
                              <Badge className={getStatusColor(withdrawal.status)}>{withdrawal.status}</Badge>
                            </div>
                            <div className="space-y-2">
                              <p className="text-emerald-600">
                                <span className="font-medium">MoMo Number:</span> {withdrawal.momo_number}
                              </p>
                              <p className="text-emerald-600">
                                <span className="font-medium">Requested:</span>{" "}
                                {formatTimestamp(withdrawal.requested_at)}
                              </p>
                              {withdrawal.paid_at && (
                                <p className="text-emerald-600">
                                  <span className="font-medium">Paid:</span> {formatTimestamp(withdrawal.paid_at)}
                                </p>
                              )}
                              {withdrawal.commission_items && withdrawal.commission_items.length > 0 && (
                                <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
                                  <p className="text-xs font-medium text-emerald-700 mb-1">Commission Sources:</p>
                                  <div className="text-xs text-emerald-600">
                                    {withdrawal.commission_items.map((item, index) => (
                                      <span key={index}>
                                        {item.type === "referral"
                                          ? "Referral"
                                          : item.type === "data_order"
                                            ? "Data Order"
                                            : "Wholesale Order"}
                                        {index < withdrawal.commission_items.length - 1 ? ", " : ""}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {getPaginatedData(tabData.withdrawals, currentWithdrawalsPage).length === 0 && (
                      <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                        <CardContent className="text-center py-8">
                          <div className="text-gray-500 mb-4">
                            <Banknote className="h-12 w-12 mx-auto mb-2 opacity-50" />
                            <p>No withdrawal requests yet.</p>
                            <p className="text-sm">Complete referrals to earn commissions and request withdrawals.</p>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                  <PaginationControls
                    currentPage={currentWithdrawalsPage}
                    totalPages={getTotalPages(tabData.withdrawals.length)}
                    onPageChange={(page) => handlePageChange(page, setCurrentWithdrawalsPage)}
                  />
                </>
              )}
            </TabsContent>
            <TabsContent value="profile" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-emerald-800">Profile Settings</h2>
              </div>
              <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-emerald-700">Full Name</Label>
                        <Input value={agent?.full_name || ""} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label className="text-emerald-700">Phone Number</Label>
                        <Input value={agent?.phone_number || ""} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label className="text-emerald-700">MoMo Number</Label>
                        <Input value={agent?.momo_number || ""} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label className="text-emerald-700">Region</Label>
                        <Input value={agent?.region || ""} disabled className="bg-gray-50" />
                      </div>
                    </div>
                    <div className="pt-4 border-t border-emerald-100">
                      <p className="text-sm text-emerald-600 mb-2">
                        To update your profile information, please contact support.
                      </p>
                      <Button
                        asChild
                        variant="outline"
                        className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                      >
                        <Link href="/agent/settings">
                          <Settings className="h-4 w-4 mr-2" />
                          Settings
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="jobs" className="space-y-4">
              {tabLoadingStates.jobs ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                  <span className="ml-3 text-emerald-700">Loading jobs...</span>
                </div>
              ) : (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <h2 className="text-2xl font-bold text-emerald-800">Job Board</h2>
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                      <Select value={jobsFilterAgent} onValueChange={setJobsFilterAgent}>
                        <SelectTrigger className="w-full sm:w-48 border-emerald-200 focus:border-emerald-500 bg-white/80 backdrop-blur-sm">
                          <Filter className="h-4 w-4 mr-2" />
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="All Jobs">All Jobs</SelectItem>
                          <SelectItem value="Featured">Featured</SelectItem>
                          <SelectItem value="Technology">Technology</SelectItem>
                          <SelectItem value="Finance">Finance</SelectItem>
                          <SelectItem value="Healthcare">Healthcare</SelectItem>
                          <SelectItem value="Marketing">Marketing</SelectItem>
                          <SelectItem value="Sales">Sales</SelectItem>
                          <SelectItem value="Customer Service">Customer Service</SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-400 h-4 w-4" />
                        <Input
                          placeholder="Search jobs..."
                          value={jobSearchTerm}
                          onChange={(e) => setJobSearchTerm(e.target.value)}
                          className="pl-10 w-full sm:w-64 border-emerald-200 focus:border-emerald-500 bg-white/80 backdrop-blur-sm"
                        />
                      </div>
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                        {filteredJobs.length} jobs
                      </Badge>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {getPaginatedData(filteredJobs, currentJobsPage).map((job) => {
                      const jobWithTitle = ensureJobTitle(job)
                      return (
                        <Card
                          key={job.id}
                          className="border-emerald-200 bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                        >
                          <CardContent className="pt-6">
                            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                              <div className="flex-1 space-y-3">
                                <h3 className="font-semibold text-emerald-800 text-lg">{jobWithTitle.title}</h3>
                                <div className="flex flex-wrap items-center gap-4 text-sm text-emerald-600">
                                  <div className="flex items-center gap-1">
                                    <Building2 className="h-4 w-4" />
                                    <span>{job.company}</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <MapPin className="h-4 w-4" />
                                    <span>{job.location}</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Briefcase className="h-4 w-4" />
                                    <span>{job.industry}</span>
                                  </div>
                                </div>
                                <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
                                  <div
                                    className="text-sm text-emerald-700 prose prose-sm max-w-none"
                                    dangerouslySetInnerHTML={{
                                      __html: job.description
                                        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
                                        .replace(/• (.*?)(?=\n|$)/g, "<li>$1</li>")
                                        .replace(
                                          /(<li>.*<\/li>)/gs,
                                          '<ul class="list-disc list-inside space-y-1">$1</ul>',
                                        )
                                        .replace(/\n/g, "<br>"),
                                    }}
                                  />
                                </div>
                                <p className="text-emerald-500 text-xs">
                                  <span className="font-medium">Posted:</span> {formatTimestamp(job.created_at)}
                                </p>
                              </div>
                              <div className="flex flex-wrap gap-2 pt-3 border-t border-emerald-100">
                                {jobWithTitle.contact_email && (
                                  <Button
                                    asChild
                                    className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                                  >
                                    <a
                                      href={`mailto:${jobWithTitle.contact_email}?subject=Application for ${jobWithTitle.title}`}
                                    >
                                      <Mail className="h-4 w-4 mr-2" />
                                      Apply via Email
                                    </a>
                                  </Button>
                                )}
                                {jobWithTitle.contact_phone && (
                                  <Button
                                    asChild
                                    variant="outline"
                                    className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                                  >
                                    <a href={`tel:${jobWithTitle.contact_phone}`}>
                                      <Smartphone className="h-4 w-4 mr-2" />
                                      Call Now
                                    </a>
                                  </Button>
                                )}
                                {jobWithTitle.application_url && (
                                  <Button
                                    asChild
                                    className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-500"
                                  >
                                    <a href={jobWithTitle.application_url} target="_blank" rel="noopener noreferrer">
                                      <ExternalLink className="h-4 w-4 mr-2" />
                                      Apply Online
                                    </a>
                                  </Button>
                                )}
                                {!job.contact_email &&
                                  !job.contact_phone &&
                                  !job.application_url &&
                                  job.application_contact && (
                                    <Button
                                      asChild
                                      className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                                    >
                                      {job.application_method === "email" ? (
                                        <a
                                          href={`mailto:${job.application_contact}?subject=Application for ${job.title}`}
                                        >
                                          <Mail className="h-4 w-4 mr-2" />
                                          Apply via Email
                                        </a>
                                      ) : (
                                        <a href={job.application_contact} target="_blank" rel="noopener noreferrer">
                                          <ExternalLink className="h-4 w-4 mr-2" />
                                          Apply Online
                                        </a>
                                      )}
                                    </Button>
                                  )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                    {getPaginatedData(filteredJobs, currentJobsPage).length === 0 && (
                      <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                        <CardContent className="text-center py-8">
                          <div className="text-gray-500 mb-4">
                            <Briefcase className="h-12 w-12 mx-auto mb-2 opacity-50" />
                            <p>
                              {jobsFilterAgent === "All Jobs"
                                ? "No jobs available at the moment."
                                : `No ${jobsFilterAgent.toLowerCase()} jobs found.`}
                            </p>
                            <p className="text-sm">Check back later for new opportunities!</p>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                  <PaginationControls
                    currentPage={currentJobsPage}
                    totalPages={getTotalPages(filteredJobs.length)}
                    onPageChange={(page) => handlePageChange(page, setCurrentJobsPage)}
                  />
                </>
              )}
            </TabsContent>
            <TabsContent value="savings" className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold text-emerald-800">Savings Management</h2>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button
                    asChild
                    className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                  >
                    <Link href="/agent/savings">
                      <PiggyBank className="h-4 w-4 mr-2" />
                      View Savings Dashboard
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                  >
                    <Link href="/agent/savings/commit">
                      <Plus className="h-4 w-4 mr-2" />
                      Start Saving
                    </Link>
                  </Button>
                </div>
              </div>
              <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                <CardContent className="pt-6 text-center py-12">
                  <PiggyBank className="h-16 w-16 mx-auto mb-4 text-emerald-300" />
                  <h3 className="text-xl font-semibold text-emerald-800 mb-2">Smart Savings Plans</h3>
                  <p className="text-emerald-600 mb-6">
                    Grow your money with our competitive savings plans. Earn interest on your deposits and build your
                    financial future.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-6">
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">High Returns</h4>
                      <p className="text-sm text-emerald-600">Earn up to 15.5% annual interest on your savings</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <Shield className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Secure & Safe</h4>
                      <p className="text-sm text-emerald-600">Your money is protected with bank-level security</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <Wallet className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Flexible Plans</h4>
                      <p className="text-sm text-emerald-600">Choose from 3-24 month savings plans</p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button
                      asChild
                      className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                    >
                      <Link href="/agent/savings">
                        <PiggyBank className="h-4 w-4 mr-2" />
                        Explore Savings Plans
                      </Link>
                    </Button>
                    <Button
                      asChild
                      variant="outline"
                      className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 bg-transparent"
                    >
                      <Link href="/agent/savings/withdraw">
                        <Banknote className="h-4 w-4 mr-2" />
                        Request Withdrawal
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="paid-commissions" className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold text-emerald-800">Paid Commissions</h2>
              </div>
              <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                <CardContent className="pt-6 text-center py-12">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto">
                      <TrendingUp className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-emerald-800 mb-2">Paid Commissions</h3>
                      <p className="text-emerald-600 mb-4">View your paid commissions history</p>
                    </div>
                    <Button
                      onClick={loadStatistics}
                      disabled={statisticsLoading}
                      className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                    >
                      {statisticsLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                          Loading Statistics...
                        </>
                      ) : (
                        <>
                          <TrendingUp className="h-4 w-4 mr-2" />
                          Load Statistics
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <div className="space-y-4">
                {getPaginatedData(tabData.paidWithdrawals, currentPaidWithdrawalsPage).map((paidWithdrawal) => (
                  <Card
                    key={paidWithdrawal.id}
                    className="border-emerald-200 bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                  >
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-emerald-800 text-lg">
                            GH₵ {safeCommissionDisplay(paidWithdrawal.amount).toFixed(2)}
                          </h3>
                          <Badge className={getStatusColor(paidWithdrawal.status)}>{paidWithdrawal.status}</Badge>
                        </div>
                        <div className="space-y-2">
                          <p className="text-emerald-600">
                            <span className="font-medium">MoMo Number:</span> {paidWithdrawal.momo_number}
                          </p>
                          <p className="text-emerald-600">
                            <span className="font-medium">Requested:</span>{" "}
                            {formatTimestamp(paidWithdrawal.requested_at)}
                          </p>
                          {paidWithdrawal.paid_at && (
                            <p className="text-emerald-600">
                              <span className="font-medium">Paid:</span> {formatTimestamp(paidWithdrawal.paid_at)}
                            </p>
                          )}
                          {paidWithdrawal.commission_items && paidWithdrawal.commission_items.length > 0 && (
                            <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
                              <p className="text-xs font-medium text-emerald-700 mb-1">Commission Sources:</p>
                              <div className="text-xs text-emerald-600">
                                {paidWithdrawal.commission_items.map((item, index) => (
                                  <span key={index}>
                                    {item.type === "referral"
                                      ? "Referral"
                                      : item.type === "data_order"
                                        ? "Data Order"
                                        : "Wholesale Order"}
                                    {index < paidWithdrawal.commission_items.length - 1 ? ", " : ""}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {getPaginatedData(tabData.paidWithdrawals, currentPaidWithdrawalsPage).length === 0 && (
                  <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                    <CardContent className="text-center py-8">
                      <div className="text-gray-500 mb-4">
                        <Banknote className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>No paid withdrawals yet.</p>
                        <p className="text-sm">Check back later for new paid withdrawals.</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
              <PaginationControls
                currentPage={currentPaidWithdrawalsPage}
                totalPages={getTotalPages(tabData.paidWithdrawals.length)}
                onPageChange={(page) => handlePageChange(page, setCurrentPaidWithdrawalsPage)}
              />
            </TabsContent>
            <TabsContent value="properties" className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold text-emerald-800">Property Promotion</h2>
                <Button
                  asChild
                  className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 w-full sm:w-auto"
                >
                  <Link href="/agent/properties">
                    <Building2 className="h-4 w-4 mr-2" />
                    Browse Properties
                  </Link>
                </Button>
              </div>
              <Card className="border-emerald-200 bg-white/90 backdrop-blur-sm">
                <CardContent className="pt-6 text-center py-12">
                  <Building2 className="h-16 w-16 mx-auto mb-4 text-emerald-300" />
                  <h3 className="text-xl font-semibold text-emerald-800 mb-2">Property Promotion Platform</h3>
                  <p className="text-emerald-600 mb-6">
                    Browse and promote real estate properties to earn commissions. Connect with potential buyers and
                    sellers through our platform.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-6">
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <Building2 className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Quality Properties</h4>
                      <p className="text-sm text-emerald-600">
                        Verified properties across multiple categories and price ranges
                      </p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <DollarSign className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Dual Currency</h4>
                      <p className="text-sm text-emerald-600">Properties listed in both Ghana Cedi and US Dollars</p>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Earn Commissions</h4>
                      <p className="text-sm text-emerald-600">
                        Connect buyers with properties and earn referral commissions
                      </p>
                    </div>
                  </div>
                  <Button
                    asChild
                    className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
                  >
                    <Link href="/agent/properties">
                      <Building2 className="h-4 w-4 mr-2" />
                      Start Promoting Properties
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="compliance" className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-emerald-800">Compliance & Registration</h2>
              </div>
              <Suspense
                fallback={
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                    <span className="ml-3 text-emerald-700">Loading compliance module...</span>
                  </div>
                }
              >
                {agent && agent.id ? (
                  <ComplianceTab agentId={agent.id} />
                ) : (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-4 border-emerald-600 border-t-transparent"></div>
                    <span className="ml-3 text-emerald-700">Loading agent data...</span>
                  </div>
                )}
              </Suspense>
            </TabsContent>
            <TabsContent value="professional-writing" className="space-y-4">
              <Suspense
                fallback={
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-4 border-pink-600 border-t-transparent"></div>
                    <span className="ml-3 text-pink-700">Loading professional writing services...</span>
                  </div>
                }
              >
                {agent && agent.id ? (
                  <ProfessionalWritingTab agentId={agent.id} />
                ) : (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-4 border-pink-600 border-t-transparent"></div>
                    <span className="ml-3 text-pink-700">Loading agent data...</span>
                  </div>
                )}
              </Suspense>
            </TabsContent>
            <TabsContent value="teaching" className="space-y-4">
              <Suspense
                fallback={
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div>
                    <span className="ml-3 text-blue-700">Loading teaching platform...</span>
                  </div>
                }
              >
                <TeachingPlatformPage />
              </Suspense>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Dialog open={showDomesticReferralDialog} onOpenChange={setShowDomesticReferralDialog}>
        <DialogContent className="w-[95vw] max-w-md bg-white/95 backdrop-blur-sm border-blue-200">
          <DialogHeader>
            <DialogTitle className="text-blue-800 flex items-center gap-2">
              <Users className="h-5 w-5" />
              Help A Friend Find Work
            </DialogTitle>
            <DialogDescription className="text-blue-600">
              Enter your friend's WhatsApp number to send them domestic job opportunities
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label htmlFor="domestic-whatsapp" className="block text-sm font-medium text-blue-700 mb-2">
                Friend's WhatsApp Number
              </label>
              <Input
                id="domestic-whatsapp"
                type="tel"
                placeholder="e.g., 0241234567 or 233241234567"
                value={domesticReferralWhatsApp}
                onChange={(e) => handleDomesticWhatsAppChange(e.target.value)}
                className={`border-blue-200 focus:border-blue-500 ${
                  domesticReferralWhatsAppError ? "border-red-300 focus:border-red-500" : ""
                }`}
              />
              {domesticReferralWhatsAppError && (
                <p className="text-red-600 text-sm mt-1">{domesticReferralWhatsAppError}</p>
              )}
            </div>
            <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
              <p className="text-sm text-blue-700">
                <strong>Preview:</strong> This will send information about domestic job opportunities with no fees, good
                salary, and protected rights.
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowDomesticReferralDialog(false)
                  setDomesticReferralWhatsApp("")
                  setDomesticReferralWhatsAppError("")
                }}
                className="flex-1 border-blue-200 text-blue-700 hover:bg-blue-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDomesticReferralSubmit}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                Send Message
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={showReferralDialog} onOpenChange={setShowReferralDialog}>
        <DialogContent className="w-[95vw] max-w-md bg-white/95 backdrop-blur-sm border-emerald-200">
          <DialogHeader>
            <DialogTitle className="text-emerald-800 flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Send Referral Message
            </DialogTitle>
            <DialogDescription className="text-emerald-600">
              Enter a WhatsApp number to send a personalized referral message
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label htmlFor="whatsapp" className="block text-sm font-medium text-emerald-700 mb-2">
                WhatsApp Number
              </label>
              <Input
                id="whatsapp"
                type="tel"
                placeholder="e.g., 0241234567 or 233241234567"
                value={referralWhatsApp}
                onChange={(e) => handleWhatsAppChange(e.target.value)}
                className={`border-emerald-200 focus:border-emerald-500 ${
                  referralWhatsAppError ? "border-red-300 focus:border-red-500" : ""
                }`}
              />
              {referralWhatsAppError && <p className="text-red-600 text-sm mt-1">{referralWhatsAppError}</p>}
            </div>
            <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200">
              <p className="text-sm text-emerald-700">
                <strong>Preview:</strong> This will send a personalized invitation message with your name and the
                registration link.
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowReferralDialog(false)
                  setReferralWhatsApp("")
                  setReferralWhatsAppError("")
                }}
                className="flex-1 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleReferralSubmit}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600"
              >
                Send Message
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      <ImageModal
        isOpen={showImageModal}
        onClose={() => setShowImageModal(false)}
        images={modalImages}
        currentIndex={modalImageIndex}
        onIndexChange={setModalImageIndex}
        alt={modalImageAlt}
      />
      <AgentReminderPopup />
      <BackToTop />
      {agent && <DashboardFloatingChat agent={agent} />}
    </div>
  )
}
