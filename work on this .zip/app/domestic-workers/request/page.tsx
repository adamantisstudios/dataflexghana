import type { Metadata } from "next"
import ClientWorkerRequestPage from "@/components/public/domestic-workers/ClientWorkerRequestPage"

export const metadata: Metadata = {
  title: "Request a Domestic Worker | DataFlex Ghana",
  description:
    "Fill out a request form to find the perfect domestic worker for your needs. Housekeepers, nannies, cleaners, and caregivers in Ghana.",
  keywords: ["domestic worker request", "housekeeping services", "nanny request", "Ghana home care"],
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "en_GH",
    url: "https://dataflexghana.com/domestic-workers/request",
    title: "Request a Domestic Worker | DataFlex Ghana",
    description: "Submit your domestic worker requirements and we'll match you with the perfect professional.",
  },
}

export default function RequestPage() {
  return <ClientWorkerRequestPage />
}
