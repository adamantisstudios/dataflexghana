import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  const cookieStore = await cookies()
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
        },
      },
    },
  )

  try {
    const { admin_id, status } = await request.json()
    const creditId = params.id

    console.log("[v0] Updating referral credit status to:", status)

    const updateData: any = {
      status,
      updated_at: new Date().toISOString(),
    }

    if (status === "confirmed") {
      updateData.confirmed_at = new Date().toISOString()
    } else if (status === "credited") {
      updateData.credited_at = new Date().toISOString()
    } else if (status === "paid_out") {
      updateData.paid_out_at = new Date().toISOString()
    }

    const { error: updateError } = await supabase.from("referral_credits").update(updateData).eq("id", creditId)

    if (updateError) {
      console.error("[v0] Error updating referral credit:", updateError)
      throw updateError
    }

    console.log("[v0] Referral credit status updated successfully")

    return NextResponse.json({
      success: true,
      message: "Payment status updated successfully",
    })
  } catch (error) {
    console.error("[v0] Error updating status:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Failed to update status",
      },
      { status: 500 },
    )
  }
}
